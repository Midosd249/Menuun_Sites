//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BNJ48e8K.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/book"],
		preloads: ["/assets/index-KhWy4JM-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-KhWy4JM-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BPZM7U1I.js"]
	},
	"/book": {
		filePath: "/workspace/src/routes/book.tsx",
		children: void 0,
		preloads: ["/assets/book-DllI6ALW.js"]
	}
} });
//#endregion
export { tsrStartManifest };
