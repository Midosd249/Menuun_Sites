import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useLocale, a as copy, d as pick, g as whatsappHref, h as timeSlots, m as services, n as Route, p as serviceById, r as cn } from "./router-CovHtyoA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book-2lY8nRhS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STORAGE_KEY = "layan-demo-requests";
function isoOffset(days) {
	const date = /* @__PURE__ */ new Date();
	date.setDate(date.getDate() + days);
	return (/* @__PURE__ */ new Date(date.getTime() - date.getTimezoneOffset() * 6e4)).toISOString().slice(0, 10);
}
function validName(value) {
	const trimmed = value.trim();
	return /^[\p{L}\s'.-]{2,60}$/u.test(trimmed);
}
function validPhone(value) {
	const compact = value.replace(/[\s-]/g, "");
	return /^(?:\+?966|0)?5\d{8}$/.test(compact);
}
function loadRequests() {
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed.slice(0, 6) : [];
	} catch {
		return [];
	}
}
function BookingForm({ initialServiceId }) {
	const { locale } = useLocale();
	const initial = serviceById(initialServiceId)?.id ?? services[0]?.id ?? "";
	const [serviceId, setServiceId] = (0, import_react.useState)(initial);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)("");
	const [time, setTime] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [sending, setSending] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(null);
	const [history, setHistory] = (0, import_react.useState)([]);
	const minDate = (0, import_react.useMemo)(() => isoOffset(0), []);
	const maxDate = (0, import_react.useMemo)(() => isoOffset(60), []);
	const selected = serviceById(serviceId) ?? services[0];
	function validate() {
		const next = {};
		if (!serviceById(serviceId)) next.service = pick(locale, copy.book.errors.service);
		if (!validName(name)) next.name = pick(locale, copy.book.errors.name);
		if (!validPhone(phone)) next.phone = pick(locale, copy.book.errors.phone);
		if (!date || date < minDate || date > maxDate) next.date = pick(locale, copy.book.errors.date);
		if (!timeSlots.includes(time)) next.time = pick(locale, copy.book.errors.time);
		setErrors(next);
		return Object.keys(next).length === 0;
	}
	async function onSubmit(event) {
		event.preventDefault();
		if (!validate()) return;
		setSending(true);
		await new Promise((resolve) => window.setTimeout(resolve, 450));
		const request = {
			id: `LY-${Date.now().toString(36).toUpperCase().slice(-6)}`,
			serviceId,
			name: name.trim(),
			phone: phone.replace(/[\s-]/g, ""),
			date,
			time
		};
		const nextHistory = [request, ...loadRequests()].slice(0, 6);
		window.localStorage.setItem(STORAGE_KEY, JSON.stringify(nextHistory));
		setHistory(nextHistory);
		setDone(request);
		setSending(false);
	}
	function reset() {
		setDone(null);
		setName("");
		setPhone("");
		setDate("");
		setTime("");
		setErrors({});
	}
	const whatsapp = done ? whatsappHref(locale === "ar" ? `مرحباً، لدي طلب تجريبي ${done.id} لخدمة ${pick(locale, selected?.name ?? services[0].name)} يوم ${done.date} الساعة ${done.time}. الاسم: ${done.name}.` : `Hello, this is demo request ${done.id} for ${pick(locale, selected?.name ?? services[0].name)} on ${done.date} at ${done.time}. Name: ${done.name}.`) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "bg-espresso px-5 py-12 text-paper sm:px-10 lg:col-span-5 lg:px-12 lg:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker text-bronze-soft",
					children: pick(locale, copy.book.kicker)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display-lg mt-4",
					children: pick(locale, copy.book.title)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-md text-sm leading-7 text-paper/75",
					children: pick(locale, copy.book.lead)
				}),
				selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServicePreview, {
					locale,
					service: selected
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-5 py-12 sm:px-10 lg:col-span-7 lg:px-12 lg:py-16",
			children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "status",
				className: "max-w-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: done.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display-lg mt-3",
						children: pick(locale, copy.book.successTitle)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-taupe",
						children: pick(locale, copy.book.successBody)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-8 border-t border-line text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
								label: pick(locale, copy.book.reference),
								value: done.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
								label: pick(locale, copy.book.service),
								value: pick(locale, selected?.name ?? services[0].name)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
								label: pick(locale, copy.book.name),
								value: done.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
								label: pick(locale, copy.book.phone),
								value: done.phone,
								ltr: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
								label: pick(locale, copy.book.date),
								value: done.date,
								ltr: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
								label: pick(locale, copy.book.time),
								value: done.time,
								ltr: true
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-solid",
							onClick: reset,
							children: pick(locale, copy.book.another)
						}), whatsapp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "btn btn-line",
							href: whatsapp,
							target: "_blank",
							rel: "noreferrer",
							children: pick(locale, copy.book.whatsappCta)
						}) : null]
					}),
					history.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-xs text-taupe",
						children: locale === "ar" ? `${history.length} طلبات تجريبية محفوظة على هذا الجهاز.` : `${history.length} demo requests saved on this device.`
					}) : null
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "max-w-xl",
				onSubmit,
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm font-medium",
							children: pick(locale, copy.book.service)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid gap-2 sm:grid-cols-2",
							children: services.map((service) => {
								const active = service.id === serviceId;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: cn("flex min-h-12 cursor-pointer items-center border px-3 text-sm transition-colors", active ? "border-ink bg-ink text-paper" : "border-line bg-paper text-ink hover:border-ink"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "radio",
										name: "service",
										value: service.id,
										checked: active,
										onChange: () => setServiceId(service.id),
										className: "sr-only"
									}), pick(locale, service.name)]
								}, service.id);
							})
						}),
						errors.service ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.service }) : null
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 grid gap-6 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: pick(locale, copy.book.name)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field",
									name: "name",
									autoComplete: "name",
									value: name,
									placeholder: pick(locale, copy.book.namePh),
									"aria-invalid": Boolean(errors.name),
									onChange: (event) => setName(event.target.value)
								}),
								errors.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.name }) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: pick(locale, copy.book.phone)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field",
									name: "tel",
									type: "tel",
									inputMode: "tel",
									autoComplete: "tel",
									dir: "ltr",
									value: phone,
									placeholder: pick(locale, copy.book.phonePh),
									"aria-invalid": Boolean(errors.phone),
									onChange: (event) => setPhone(event.target.value)
								}),
								errors.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.phone }) : null
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-8 block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium",
								children: pick(locale, copy.book.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								type: "date",
								name: "date",
								dir: "ltr",
								min: minDate,
								max: maxDate,
								value: date,
								"aria-invalid": Boolean(errors.date),
								onChange: (event) => setDate(event.target.value)
							}),
							errors.date ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.date }) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "mt-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-medium",
								children: pick(locale, copy.book.time)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 grid grid-cols-3 gap-2 sm:grid-cols-4",
								children: timeSlots.map((slot) => {
									const active = slot === time;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": active,
										onClick: () => setTime(slot),
										className: cn("min-h-11 border text-sm tabular-nums transition-colors", active ? "border-ink bg-ink text-paper" : "border-line bg-paper hover:border-ink"),
										children: slot
									}, slot);
								})
							}),
							errors.time ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.time }) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn btn-solid mt-10 w-full sm:w-auto",
						disabled: sending,
						children: sending ? pick(locale, copy.book.sending) : pick(locale, copy.book.submit)
					})
				]
			})
		})]
	});
}
function ServicePreview({ locale, service }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "mt-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative aspect-[5/4] overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: service.image,
				alt: pick(locale, service.alt),
				className: "absolute inset-0 h-full w-full object-cover"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "display text-3xl",
				children: pick(locale, service.name)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-paper/70",
				children: [
					pick(locale, service.duration),
					" · ",
					pick(locale, service.price)
				]
			})]
		})]
	});
}
function SummaryRow({ label, value, ltr = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-1 border-b border-line py-3 sm:grid-cols-[9rem_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-taupe",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			dir: ltr ? "ltr" : void 0,
			className: ltr ? "text-start" : void 0,
			children: value
		})]
	});
}
function FieldError({ message }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "mt-2 text-sm text-bronze",
		children: message
	});
}
function BookPage() {
	const { service } = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		id: "content",
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingForm, { initialServiceId: service }, service ?? "open")
	});
}
//#endregion
export { BookPage as component };
