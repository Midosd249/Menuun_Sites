import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CovHtyoA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var LocaleContext = (0, import_react.createContext)(null);
function LocaleProvider({ children }) {
	const [locale, setLocale] = (0, import_react.useState)("ar");
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const stored = window.localStorage.getItem("layan-locale");
		if (stored === "en" || stored === "ar") setLocale(stored);
		document.documentElement.classList.add("js");
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = locale;
		document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";
		if (!ready) return;
		window.localStorage.setItem("layan-locale", locale);
	}, [locale, ready]);
	const value = (0, import_react.useMemo)(() => ({
		locale,
		setLocale,
		toggle: () => setLocale((current) => current === "ar" ? "en" : "ar")
	}), [locale]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocaleContext.Provider, {
		value,
		children
	});
}
function useLocale() {
	const value = (0, import_react.useContext)(LocaleContext);
	if (!value) throw new Error("useLocale must be used within LocaleProvider");
	return value;
}
/**
* Demo salon identity. Replace these values when customizing for a real client.
* Leave unknown contact fields empty — the site shows a clear placeholder
* instead of inventing an address, phone, or map pin.
*/
var salonConfig = {
	brand: {
		ar: "ليان",
		en: "Layan"
	},
	atelier: {
		ar: "أتيليه",
		en: "Atelier"
	},
	city: {
		ar: "الرياض",
		en: "Riyadh"
	},
	/** Digits only, country code included, no plus. Example: 9665XXXXXXXX */
	whatsappE164: "",
	/** Shown to visitors. Example: +966 5X XXX XXXX */
	phoneDisplay: "",
	address: {
		ar: "",
		en: ""
	},
	hours: {
		ar: "",
		en: ""
	},
	/** https://instagram.com/... — leave empty to hide the link */
	instagramUrl: "",
	/** https maps embed URL — leave empty to show the map placeholder */
	mapEmbedUrl: ""
};
var services = [
	{
		id: "styling",
		image: "/images/hair.jpg",
		name: {
			ar: "تصفيف الشعر",
			en: "Hair styling"
		},
		summary: {
			ar: "قصّة أو تسريحة أو لمسة أخيرة قبل خروجك. نبدأ بشكل الشعر وما يناسب يومك.",
			en: "A cut, a finish, or a look for later today. We start with your hair and the day you have in mind."
		},
		duration: {
			ar: "٤٥–٧٥ دقيقة",
			en: "45–75 min"
		},
		price: {
			ar: "من ١٨٠ ر.س",
			en: "from SAR 180"
		},
		alt: {
			ar: "مصففة تجفف الشعر بفرشاة دائرية داخل الصالون",
			en: "A stylist blow-drying hair with a round brush"
		}
	},
	{
		id: "color",
		image: "/images/color.jpg",
		name: {
			ar: "تلوين الشعر",
			en: "Hair color"
		},
		summary: {
			ar: "لون كامل أو خصلات أخف، بعد حديث عن الدرجة والعناية التي تليها.",
			en: "A full color or a lighter placement, after we talk through the tone and the care that follows."
		},
		duration: {
			ar: "٩٠–١٥٠ دقيقة",
			en: "90–150 min"
		},
		price: {
			ar: "من ٣٢٠ ر.س",
			en: "from SAR 320"
		},
		alt: {
			ar: "شطف الشعر بهدوء بعد جلسة عناية في حوض الغسيل",
			en: "Hair being rinsed at a salon basin"
		}
	},
	{
		id: "manicure",
		image: "/images/manicure.jpg",
		name: {
			ar: "عناية الأظافر",
			en: "Nail care"
		},
		summary: {
			ar: "مانيكير وباديكير بتشذيب نظيف ولون هادئ، من غير استعجال.",
			en: "A manicure and pedicure with a clean shape and a quiet color, unhurried."
		},
		duration: {
			ar: "٤٥–٧٠ دقيقة",
			en: "45–70 min"
		},
		price: {
			ar: "من ١٢٠ ر.س",
			en: "from SAR 120"
		},
		alt: {
			ar: "يدان بأظافر مطلية بلون وردي هادئ",
			en: "Hands with a soft pink manicure"
		}
	},
	{
		id: "nailart",
		image: "/images/nails.jpg",
		name: {
			ar: "رسم الأظافر",
			en: "Nail art"
		},
		summary: {
			ar: "نقش خفيف أو لمسة أوضح. تختارين الدرجة، وننفّذها بدقة.",
			en: "A faint pattern or a clearer gesture. You choose the tone; we place it carefully."
		},
		duration: {
			ar: "٦٠–٩٠ دقيقة",
			en: "60–90 min"
		},
		price: {
			ar: "من ١٦٠ ر.س",
			en: "from SAR 160"
		},
		alt: {
			ar: "أظافر بطلاء أسود لامع ونقش كهرماني",
			en: "Glossy black nails with an amber tortoiseshell accent"
		}
	},
	{
		id: "skin",
		image: "/images/facial.jpg",
		name: {
			ar: "عناية البشرة",
			en: "Skin care"
		},
		summary: {
			ar: "جلسة تنظيف وعناية بالوجه. راحة وخطوات واضحة، من غير وعود طبية.",
			en: "A facial of cleansing and care. Rest, and a clear sequence — not a medical promise."
		},
		duration: {
			ar: "٥٠–٧٥ دقيقة",
			en: "50–75 min"
		},
		price: {
			ar: "من ٢٢٠ ر.س",
			en: "from SAR 220"
		},
		alt: {
			ar: "وضع قناع عناية على بشرة الوجه داخل الجلسة",
			en: "A clay mask being applied during a facial"
		}
	},
	{
		id: "bridal",
		image: "/images/portrait.jpg",
		name: {
			ar: "إطلالة العروس",
			en: "Bridal beauty"
		},
		summary: {
			ar: "شعر ومكياج ليوم الزفاف. نرتّب الوقت مسبقاً، والسعر يُحدَّد بعد الاستشارة.",
			en: "Hair and makeup for the wedding day. Time is arranged ahead, and the fee follows a consultation."
		},
		duration: {
			ar: "حسب الترتيب",
			en: "By arrangement"
		},
		price: {
			ar: "بعد الاستشارة",
			en: "After consultation"
		},
		alt: {
			ar: "لقطة قريبة لوضع أحمر الشفاه ضمن مكياج العناية",
			en: "A close view of lipstick being applied"
		}
	}
];
var gallery = [
	{
		id: "wash",
		image: "/images/stylist.jpg",
		tall: true,
		alt: {
			ar: "غسل الشعر في حوض الصالون",
			en: "Hair being washed at the salon basin"
		},
		caption: {
			ar: "غسل الشعر",
			en: "Hair wash"
		}
	},
	{
		id: "studio",
		image: "/images/interior.jpg",
		wide: true,
		alt: {
			ar: "صالة تصفيف بإضاءة النهار والمرايا",
			en: "Styling floor with daylight and mirrors"
		},
		caption: {
			ar: "صالة التصفيف",
			en: "The floor"
		}
	},
	{
		id: "nails-session",
		image: "/images/nailart.jpg",
		alt: {
			ar: "أخصائية تنهي العناية بطرف الظفر",
			en: "A nail artist finishing the tip of a nail"
		},
		caption: {
			ar: "جلسة الأظافر",
			en: "Nail session"
		}
	},
	{
		id: "polish",
		image: "/images/hands.jpg",
		alt: {
			ar: "أظافر بألوان رمادية وبيضاء هادئة",
			en: "Nails in quiet grey and white polish"
		},
		caption: {
			ar: "ألوان هادئة",
			en: "Quiet color"
		}
	},
	{
		id: "tools",
		image: "/images/soft.jpg",
		alt: {
			ar: "فرش مكياج في إناء معدني",
			en: "Makeup brushes standing in a metal cup"
		},
		caption: {
			ar: "أدوات المكياج",
			en: "Makeup tools"
		}
	},
	{
		id: "brow",
		image: "/images/brow.jpg",
		wide: true,
		alt: {
			ar: "تحديد الحاجب بخيط خلال جلسة عناية",
			en: "Brows being shaped with thread"
		},
		caption: {
			ar: "تحديد الحاجب",
			en: "Brow shaping"
		}
	}
];
var timeSlots = Array.from({ length: 20 }, (_, index) => {
	const total = 660 + index * 30;
	const hours = Math.floor(total / 60);
	const minutes = total % 60;
	return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
});
function serviceById(id) {
	return services.find((service) => service.id === id);
}
function whatsappHref(message) {
	const digits = salonConfig.whatsappE164.replace(/\D/g, "");
	if (!/^\d{8,15}$/.test(digits)) return null;
	return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}
function phoneHref() {
	const compact = salonConfig.phoneDisplay.replace(/[^\d+]/g, "");
	if (compact.replace(/\D/g, "").length < 8) return null;
	return `tel:${compact}`;
}
function instagramHref() {
	const value = salonConfig.instagramUrl.trim();
	if (!value.startsWith("https://")) return null;
	return value;
}
function mapEmbedHref() {
	const value = salonConfig.mapEmbedUrl.trim();
	if (!value.startsWith("https://")) return null;
	try {
		const host = new URL(value).hostname;
		return host === "www.google.com" || host === "maps.google.com" || host.endsWith(".google.com") || host === "www.openstreetmap.org" || host.endsWith(".openstreetmap.org") ? value : null;
	} catch {
		return null;
	}
}
var pending = {
	ar: "يُضاف عند التخصيص",
	en: "Added when you customize"
};
function configuredText(locale, value) {
	return value[locale].trim() || pending[locale];
}
function isConfigured(value) {
	return Boolean(value.ar.trim() || value.en.trim());
}
var copy = {
	skip: {
		ar: "تخطّي إلى المحتوى",
		en: "Skip to content"
	},
	nav: {
		services: {
			ar: "الخدمات",
			en: "Services"
		},
		story: {
			ar: "القصة",
			en: "Story"
		},
		gallery: {
			ar: "المعرض",
			en: "Gallery"
		},
		visit: {
			ar: "الزيارة",
			en: "Visit"
		},
		book: {
			ar: "احجزي موعدك",
			en: "Book a visit"
		},
		bookShort: {
			ar: "احجزي",
			en: "Book"
		},
		menu: {
			ar: "القائمة",
			en: "Menu"
		},
		close: {
			ar: "إغلاق",
			en: "Close"
		},
		language: {
			ar: "English",
			en: "العربية"
		}
	},
	hero: {
		kicker: {
			ar: "صالون نسائي في الرياض",
			en: "A women’s salon in Riyadh"
		},
		title: {
			ar: "حيث تُصاغ التفاصيل بهدوء",
			en: "Where detail is shaped in quiet"
		},
		lead: {
			ar: "عناية بالشعر والبشرة والأظافر. جلسة على مهلك، تبدأ بسؤال قصير: ماذا تريدين اليوم؟",
			en: "Care for hair, skin, and nails. An unhurried session that starts with a short question: what do you want today?"
		},
		primary: {
			ar: "احجزي موعدك",
			en: "Book a visit"
		},
		secondary: {
			ar: "استعرضي الخدمات",
			en: "View services"
		},
		caption: {
			ar: "تصفيف داخل الصالون",
			en: "Styling, in the salon"
		},
		signature: {
			ar: "أتيليه ليان",
			en: "Atelier Layan"
		}
	},
	services: {
		kicker: {
			ar: "القائمة",
			en: "The list"
		},
		title: {
			ar: "ست خدمات، بلا ازدحام",
			en: "Six services, uncluttered"
		},
		lead: {
			ar: "كل باب يفتح على طلب حجز. المدد والأسعار أمثلة للعرض، وتُستبدل بقائمة الصالون الفعلية.",
			en: "Each one opens a booking request. Durations and prices are examples for this demo, ready to be replaced."
		},
		book: {
			ar: "اطلبي هذه الخدمة",
			en: "Request this service"
		},
		illustrative: {
			ar: "سعر توضيحي",
			en: "Illustrative price"
		}
	},
	story: {
		kicker: {
			ar: "القصة",
			en: "The house"
		},
		title: {
			ar: "نبدأ بالسؤال، لا بالمقص",
			en: "We begin with a question, not the scissors"
		},
		body: {
			ar: "ليان مكان صغير للعناية، لا سلسلة ولا وعد بنتيجة جاهزة. نسمع الطلب، نرتّب الوقت، ثم نعمل بهدوء حتى آخر لمسة.",
			en: "Layan is a small house of care, not a chain and not a promise of a finished result. We listen, we set the time, then we work quietly through the last detail."
		},
		points: [
			{
				title: {
					ar: "استماع أولاً",
					en: "Listening first"
				},
				text: {
					ar: "دقائق في البداية لفهم ما تريدينه قبل أن تبدأ الخدمة.",
					en: "A few minutes at the start, so the service follows what you actually want."
				}
			},
			{
				title: {
					ar: "وقت محسوب",
					en: "Time with room in it"
				},
				text: {
					ar: "لكل خدمة مدة ظاهرة، حتى لا تتزاحم المواعيد فوق بعضها.",
					en: "Every service shows its duration, so appointments are not stacked on top of each other."
				}
			},
			{
				title: {
					ar: "طلب لا تأكيد",
					en: "A request, not a confirmation"
				},
				text: {
					ar: "ما يُرسل من الموقع طلب زيارة. الموعد يثبت حين يرد الصالون.",
					en: "What the site sends is a request. The visit is set when the salon replies."
				}
			}
		]
	},
	gallery: {
		kicker: {
			ar: "المعرض",
			en: "Gallery"
		},
		title: {
			ar: "ضوء، أدوات، وأيدٍ تعمل",
			en: "Light, tools, and hands at work"
		},
		lead: {
			ar: "لقطات للعناية والمكان. ليست صوراً لضيفات، ولا نتائج قبل وبعد.",
			en: "Frames of the work and the room. Not guest portraits, and not before-and-after claims."
		},
		open: {
			ar: "تكبير الصورة",
			en: "Enlarge image"
		},
		close: {
			ar: "إغلاق المعرض",
			en: "Close gallery"
		},
		prev: {
			ar: "الصورة السابقة",
			en: "Previous image"
		},
		next: {
			ar: "الصورة التالية",
			en: "Next image"
		}
	},
	experience: {
		kicker: {
			ar: "الزيارة",
			en: "The visit"
		},
		title: {
			ar: "ثلاث خطوات، من غير تعقيد",
			en: "Three steps, and no fuss"
		},
		steps: [
			{
				title: {
					ar: "تختارين الخدمة",
					en: "Choose the service"
				},
				text: {
					ar: "من القائمة مباشرة، أو تتركين الاختيار مفتوحاً ونرتّبه معك.",
					en: "From the list, or leave it open and we arrange it with you."
				}
			},
			{
				title: {
					ar: "تحدّدين يوماً ووقتاً",
					en: "Pick a day and a time"
				},
				text: {
					ar: "الأوقات في هذا النموذج توضيحية، وتصير جدول الصالون عند الربط.",
					en: "Times in this demo are illustrative. They become the salon’s own schedule once connected."
				}
			},
			{
				title: {
					ar: "يصل طلب، لا موعد مؤكد",
					en: "A request arrives, not a confirmed booking"
				},
				text: {
					ar: "ترسلين بياناتك، ويظهر رقم طلب تجريبي. التأكيد الفعلي يتم خارج هذا النموذج.",
					en: "You send your details and receive a demo request number. A real confirmation happens outside this demo."
				}
			}
		]
	},
	visit: {
		kicker: {
			ar: "التواصل",
			en: "Contact"
		},
		title: {
			ar: "العنوان والوقت، حين تكتمل البيانات",
			en: "Address and hours, once they are real"
		},
		lead: {
			ar: "لا نعرض عنواناً أو رقماً غير موجود. الحقول التالية تنتظر بيانات الصالون.",
			en: "We do not show an address or a number that does not exist. These fields wait for the salon’s own details."
		},
		address: {
			ar: "العنوان",
			en: "Address"
		},
		phone: {
			ar: "الهاتف",
			en: "Phone"
		},
		hours: {
			ar: "ساعات العمل",
			en: "Hours"
		},
		whatsapp: {
			ar: "واتساب",
			en: "WhatsApp"
		},
		whatsappMissing: {
			ar: "واتساب يظهر بعد إضافة الرقم",
			en: "WhatsApp appears after the number is added"
		},
		instagram: {
			ar: "إنستغرام",
			en: "Instagram"
		},
		mapTitle: {
			ar: "خريطة الصالون",
			en: "Salon map"
		},
		mapEmpty: {
			ar: "الخريطة تُربط بعنوان الصالون عند التخصيص.",
			en: "The map is connected to the salon’s address when you customize the site."
		},
		book: {
			ar: "ابدئي طلب الحجز",
			en: "Start a booking request"
		}
	},
	book: {
		kicker: {
			ar: "طلب موعد",
			en: "Booking request"
		},
		title: {
			ar: "أخبرينا متى يناسبك الحضور",
			en: "Tell us when you would like to come"
		},
		lead: {
			ar: "هذا النموذج تجريبي. الطلب يُحفظ على جهازك فقط، ولا يُعد موعداً مؤكداً.",
			en: "This form is a demo. The request stays on your device and is not a confirmed appointment."
		},
		service: {
			ar: "الخدمة",
			en: "Service"
		},
		name: {
			ar: "الاسم",
			en: "Name"
		},
		phone: {
			ar: "الجوال",
			en: "Mobile"
		},
		date: {
			ar: "اليوم",
			en: "Day"
		},
		time: {
			ar: "الوقت",
			en: "Time"
		},
		submit: {
			ar: "إرسال الطلب",
			en: "Send request"
		},
		sending: {
			ar: "جارٍ الإرسال",
			en: "Sending"
		},
		namePh: {
			ar: "اسمك الكريم",
			en: "Your name"
		},
		phonePh: {
			ar: "05xxxxxxxx",
			en: "05xxxxxxxx"
		},
		successTitle: {
			ar: "وصل طلبك التجريبي",
			en: "Your demo request is in"
		},
		successBody: {
			ar: "احتفظنا بالتفاصيل على هذا الجهاز. لم يُثبَّت موعد حقيقي، ولم تُرسل رسالة إلى صالون.",
			en: "The details are stored on this device. No real appointment was confirmed, and nothing was sent to a salon."
		},
		reference: {
			ar: "رقم الطلب التجريبي",
			en: "Demo request number"
		},
		another: {
			ar: "طلب جديد",
			en: "New request"
		},
		whatsappCta: {
			ar: "تابعي عبر واتساب",
			en: "Continue on WhatsApp"
		},
		errors: {
			service: {
				ar: "اختاري خدمة.",
				en: "Choose a service."
			},
			name: {
				ar: "اكتبي الاسم كما تحبين أن نناديك.",
				en: "Add the name you would like us to use."
			},
			phone: {
				ar: "أدخلي رقم جوال سعودي صحيح، مثل 05xxxxxxxx.",
				en: "Enter a valid Saudi mobile, such as 05xxxxxxxx."
			},
			date: {
				ar: "اختاري يوماً قادماً خلال الشهرين التاليين.",
				en: "Choose a coming day within the next two months."
			},
			time: {
				ar: "اختاري وقتاً من القائمة.",
				en: "Choose a time from the list."
			}
		}
	},
	footer: {
		line: {
			ar: "نموذج موقع لصالون تجميل في الرياض. الاسم والصور وبيانات التواصل قابلة للتخصيص.",
			en: "A website demo for a Riyadh beauty salon. The name, photographs, and contact details can be customized."
		},
		rights: {
			ar: "جميع الحقوق محفوظة للنموذج التصميمي.",
			en: "Design demo. All rights reserved."
		},
		photos: {
			ar: "الصور الفوتوغرافية من Unsplash.",
			en: "Photographs from Unsplash."
		}
	}
};
function pick(locale, value) {
	return value[locale];
}
function Footer() {
	const { locale } = useLocale();
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	const phone = phoneHref();
	const whatsapp = whatsappHref(pick(locale, copy.hero.signature));
	const instagram = instagramHref();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-ink bg-ivory",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shell-wide grid gap-10 py-14 md:grid-cols-[1.4fr_1fr_1fr] md:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: pick(locale, salonConfig.atelier)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "display mt-2 text-5xl",
						children: pick(locale, salonConfig.brand)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-sm text-sm text-taupe",
						children: pick(locale, copy.footer.line)
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex flex-col gap-3 text-sm",
					"aria-label": pick(locale, copy.nav.menu),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/#services",
							children: pick(locale, copy.nav.services)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/#story",
							children: pick(locale, copy.nav.story)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/#gallery",
							children: pick(locale, copy.nav.gallery)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/#visit",
							children: pick(locale, copy.nav.visit)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-start gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/book",
							className: "btn btn-solid",
							children: pick(locale, copy.nav.book)
						}),
						phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: phone,
							className: "text-sm",
							children: salonConfig.phoneDisplay
						}) : null,
						whatsapp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: whatsapp,
							className: "text-sm",
							target: "_blank",
							rel: "noreferrer",
							children: pick(locale, copy.visit.whatsapp)
						}) : null,
						instagram ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: instagram,
							className: "text-sm",
							target: "_blank",
							rel: "noreferrer",
							children: pick(locale, copy.visit.instagram)
						}) : null
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shell-wide flex flex-col gap-2 border-t border-line py-5 text-xs text-taupe sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"© ",
				year,
				" ",
				pick(locale, copy.hero.signature),
				". ",
				pick(locale, copy.footer.rights)
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: pick(locale, copy.footer.photos) })]
		})]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var links = [
	{
		href: "/#services",
		key: "services"
	},
	{
		href: "/#story",
		key: "story"
	},
	{
		href: "/#gallery",
		key: "gallery"
	},
	{
		href: "/#visit",
		key: "visit"
	}
];
function Header() {
	const { locale, toggle } = useLocale();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 8);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("sticky top-0 z-40 border-b bg-ivory/92 backdrop-blur-md", scrolled ? "border-ink/20" : "border-line"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "sr-only focus:not-sr-only focus:absolute focus:z-50 focus:m-3 focus:bg-paper focus:px-3 focus:py-2",
				children: pick(locale, copy.skip)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell-wide flex items-center justify-between gap-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex flex-col leading-none",
						"aria-label": pick(locale, copy.hero.signature),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "kicker",
							children: pick(locale, salonConfig.atelier)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "display text-3xl",
							children: pick(locale, salonConfig.brand)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "hidden items-center gap-8 lg:flex",
						"aria-label": pick(locale, copy.nav.menu),
						children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: link.href,
							className: "text-sm text-ink transition-colors hover:text-bronze",
							children: pick(locale, copy.nav[link.key])
						}, link.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: toggle,
								className: "btn btn-ghost px-2 text-sm",
								"aria-label": pick(locale, copy.nav.language),
								children: pick(locale, copy.nav.language)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/book",
								className: "btn btn-solid hidden sm:inline-flex",
								children: pick(locale, copy.nav.book)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/book",
								className: "btn btn-solid sm:hidden",
								children: pick(locale, copy.nav.bookShort)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-line px-3 lg:hidden",
								"aria-expanded": open,
								"aria-controls": "mobile-nav",
								onClick: () => setOpen((value) => !value),
								children: open ? pick(locale, copy.nav.close) : pick(locale, copy.nav.menu)
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "mobile-nav",
				className: cn("fixed inset-0 z-50 flex flex-col bg-ivory px-6 pb-10 pt-6 transition-opacity duration-200 lg:hidden", open ? "visible opacity-100" : "invisible pointer-events-none opacity-0"),
				hidden: !open,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "display text-3xl",
							children: pick(locale, salonConfig.brand)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-line",
							onClick: () => setOpen(false),
							children: pick(locale, copy.nav.close)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-12 flex flex-col gap-6",
						"aria-label": pick(locale, copy.nav.menu),
						children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: link.href,
							onClick: () => setOpen(false),
							className: "display text-4xl",
							children: pick(locale, copy.nav[link.key])
						}, link.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/book",
							className: "btn btn-solid w-full",
							onClick: () => setOpen(false),
							children: pick(locale, copy.nav.book)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-line w-full",
							onClick: toggle,
							children: pick(locale, copy.nav.language)
						})]
					})
				]
			})
		]
	});
}
var styles_default = "/assets/styles-mjCLQ5sg.css";
var Route$2 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "أتيليه ليان — صالون تجميل في الرياض" },
			{
				name: "description",
				content: "أتيليه ليان: موقع تجريبي لصالون تجميل نسائي في الرياض. شعر، بشرة، وأظافر، مع طلب حجز واضح قابل للتخصيص."
			},
			{
				name: "theme-color",
				content: "#f3eee6"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LocaleProvider, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
			] }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$1 = () => import("./routes-K0K1zoxS.mjs");
var Route$1 = createFileRoute("/")({
	head: () => ({
		meta: [{ title: "أتيليه ليان — صالون تجميل في الرياض" }, {
			name: "description",
			content: "تجربة موقع لصالون نسائي في الرياض: تصفيف، تلوين، أظافر، عناية بالبشرة، وإطلالة عروس، مع طلب حجز تجريبي."
		}],
		links: [{
			rel: "preload",
			as: "image",
			href: "/images/hero.jpg"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./book-2lY8nRhS.mjs");
var Route = createFileRoute("/book")({
	validateSearch: (search) => ({ service: typeof search.service === "string" ? search.service : void 0 }),
	head: () => ({ meta: [{ title: "طلب موعد — أتيليه ليان" }, {
		name: "description",
		content: "اطلبي موعداً تجريبياً في أتيليه ليان: اختاري الخدمة، اليوم، والوقت. الطلب لا يُعد تأكيداً نهائياً."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$2
	}),
	BookRoute: Route.update({
		id: "/book",
		path: "/book",
		getParentRoute: () => Route$2
	})
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { useLocale as _, copy as a, isConfigured as c, pick as d, salonConfig as f, whatsappHref as g, timeSlots as h, configuredText as i, mapEmbedHref as l, services as m, Route as n, gallery as o, serviceById as p, cn as r, instagramHref as s, router_exports as t, phoneHref as u };
