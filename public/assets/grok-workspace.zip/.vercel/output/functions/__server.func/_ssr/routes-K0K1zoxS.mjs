import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useLocale, a as copy, c as isConfigured, d as pick, f as salonConfig, g as whatsappHref, i as configuredText, l as mapEmbedHref, m as services, o as gallery, r as cn, s as instagramHref, u as phoneHref } from "./router-CovHtyoA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-K0K1zoxS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Reveal({ children, className, delay = 0 }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const node = ref.current;
		if (!node) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			node.classList.add("is-in");
			return;
		}
		const observer = new IntersectionObserver((entries) => {
			if (entries.some((entry) => entry.isIntersecting)) {
				node.classList.add("is-in");
				observer.disconnect();
			}
		}, {
			threshold: .18,
			rootMargin: "0px 0px -8% 0px"
		});
		observer.observe(node);
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: cn("reveal", className),
		style: delay ? { transitionDelay: `${delay}ms` } : void 0,
		children
	});
}
function Experience() {
	const { locale } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-espresso text-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shell py-16 md:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker text-bronze-soft",
					children: pick(locale, copy.experience.kicker)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display-lg mt-4 max-w-3xl",
					children: pick(locale, copy.experience.title)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-12 grid gap-10 md:grid-cols-3",
					children: copy.experience.steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-t border-paper/15 pt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
							delay: index * 90,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "display text-4xl text-bronze-soft tabular-nums",
									children: ["0", index + 1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 text-xl font-medium",
									children: pick(locale, step.title)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-7 text-paper/80",
									children: pick(locale, step.text)
								})
							]
						})
					}, step.title.en))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/book",
					className: "btn btn-paper mt-12",
					children: pick(locale, copy.nav.book)
				}) })
			]
		})
	});
}
function Gallery() {
	const { locale } = useLocale();
	const [active, setActive] = (0, import_react.useState)(null);
	const dialogRef = (0, import_react.useRef)(null);
	const titleId = (0, import_react.useId)();
	(0, import_react.useEffect)(() => {
		const dialog = dialogRef.current;
		if (!dialog) return;
		if (active === null) {
			if (dialog.open) dialog.close();
			return;
		}
		if (!dialog.open) dialog.showModal();
	}, [active]);
	const current = active === null ? null : gallery[active];
	function step(direction) {
		setActive((index) => {
			if (index === null) return index;
			return (index + direction + gallery.length) % gallery.length;
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "gallery",
		className: "border-t border-line",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shell py-16 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: pick(locale, copy.gallery.kicker)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col justify-between gap-5 md:flex-row md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display-lg max-w-xl",
					children: pick(locale, copy.gallery.title)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm text-taupe",
					children: pick(locale, copy.gallery.lead)
				})]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "gallery-grid mt-10",
				children: gallery.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: cn("relative", item.wide && "g-wide", item.tall && "g-tall"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "g-frame group media-zoom relative block w-full overflow-hidden bg-cream text-start",
						onClick: () => setActive(index),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: item.image,
							alt: pick(locale, item.alt),
							className: "absolute inset-0 h-full w-full object-cover",
							loading: "lazy",
							decoding: "async"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: pick(locale, copy.gallery.open)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "pointer-events-none absolute inset-x-0 bottom-0 bg-espresso px-3 py-2 text-xs text-paper",
						children: pick(locale, item.caption)
					})]
				}, item.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dialog", {
			ref: dialogRef,
			"aria-labelledby": titleId,
			className: "m-auto w-[min(68rem,calc(100%-1.5rem))] border-0 bg-transparent p-0 backdrop:bg-espresso/80",
			onClose: () => setActive(null),
			onClick: (event) => {
				if (event.target === dialogRef.current) setActive(null);
			},
			children: current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-espresso text-paper",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: titleId,
							className: "text-sm",
							children: pick(locale, current.caption)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-paper",
							onClick: () => setActive(null),
							children: pick(locale, copy.gallery.close)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: current.image,
						alt: pick(locale, current.alt),
						className: "max-h-[72vh] w-full object-contain bg-ink"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-3 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-paper",
							onClick: () => step(-1),
							children: pick(locale, copy.gallery.prev)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-paper",
							onClick: () => step(1),
							children: pick(locale, copy.gallery.next)
						})]
					})
				]
			}) : null
		})]
	});
}
function Hero() {
	const { locale } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid lg:min-h-[calc(100svh-5.25rem)] lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hero-media relative lg:col-span-7",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/hero.jpg",
				alt: pick(locale, {
					ar: "مصففة تصفف الشعر داخل صالون مضيء",
					en: "A stylist finishing hair in a bright salon"
				}),
				className: "absolute inset-0 h-full w-full object-cover",
				fetchPriority: "high",
				decoding: "async"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "absolute bottom-4 start-4 bg-espresso px-3 py-2 text-xs text-paper",
				children: pick(locale, copy.hero.caption)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col justify-between gap-10 bg-paper px-5 py-10 sm:px-10 lg:col-span-5 lg:px-12 lg:py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker hero-rise",
					children: pick(locale, copy.hero.kicker)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "display-xl hero-rise delay-1",
							children: pick(locale, copy.hero.title)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-md text-base text-ink/80 hero-rise delay-2 sm:text-lg",
							children: pick(locale, copy.hero.lead)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 hero-rise delay-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/book",
								className: "btn btn-solid",
								children: pick(locale, copy.hero.primary)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#services",
								className: "btn btn-line",
								children: pick(locale, copy.hero.secondary)
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center justify-between gap-4 border-t border-line pt-5 text-sm text-taupe hero-rise delay-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "display text-2xl text-ink",
						children: pick(locale, salonConfig.brand)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pick(locale, salonConfig.city) })]
				})
			]
		})]
	});
}
function Services() {
	const { locale } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "services",
		className: "border-t border-line",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shell py-16 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: pick(locale, copy.services.kicker)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display-lg mt-4 max-w-3xl",
					children: pick(locale, copy.services.title)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-2xl text-taupe",
					children: pick(locale, copy.services.lead)
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-8 flex flex-wrap gap-x-6 gap-y-3",
				"aria-label": pick(locale, copy.nav.services),
				children: services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `#service-${service.id}`,
					className: "border-b border-transparent text-sm hover:border-bronze",
					children: pick(locale, service.name)
				}, service.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: services.map((service, index) => {
			const flip = index % 2 === 1;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				id: `service-${service.id}`,
				className: "grid border-t border-line lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
					className: cn("service-media group media-zoom relative overflow-hidden bg-cream lg:col-span-5", flip && "lg:col-start-8"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: service.image,
						alt: pick(locale, service.alt),
						className: "absolute inset-0 h-full w-full object-cover",
						loading: "lazy",
						decoding: "async"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("flex flex-col justify-center gap-5 px-5 py-10 sm:px-10 lg:col-span-7 lg:px-16 lg:py-16", flip && "lg:col-start-1 lg:row-start-1"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "kicker tabular-nums",
							children: ["0", index + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "display text-4xl sm:text-5xl",
							children: pick(locale, service.name)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-xl text-ink/85",
							children: pick(locale, service.summary)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex flex-wrap gap-x-4 gap-y-1 text-sm text-taupe",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pick(locale, service.duration) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									children: "·"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pick(locale, service.price) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									children: "·"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pick(locale, copy.services.illustrative) })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/book",
							search: { service: service.id },
							className: "btn btn-ghost w-fit border-b border-ink px-0",
							children: pick(locale, copy.services.book)
						})
					]
				})]
			}, service.id);
		}) })]
	});
}
function Story() {
	const { locale } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "story",
		className: "border-t border-line bg-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-16 sm:px-10 lg:col-span-7 lg:px-16 lg:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: pick(locale, copy.story.kicker)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display-lg mt-4 max-w-xl",
						children: pick(locale, copy.story.title)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xl text-lg",
						children: pick(locale, copy.story.body)
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-12 grid gap-8 border-t border-line pt-8 md:grid-cols-3",
					children: copy.story.points.map((point, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: index * 80,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "display text-3xl text-bronze tabular-nums",
								children: ["0", index + 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-lg font-medium",
								children: pick(locale, point.title)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-taupe",
								children: pick(locale, point.text)
							})
						]
					}) }, point.title.en))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
				className: "relative min-h-80 lg:col-span-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/mirrors.jpg",
					alt: pick(locale, {
						ar: "كراسي التصفيف أمام مرآة الصالون",
						en: "Styling chairs in front of the salon mirror"
					}),
					className: "absolute inset-0 h-full w-full object-cover",
					loading: "lazy",
					decoding: "async"
				})
			})]
		})
	});
}
function Visit() {
	const { locale } = useLocale();
	const phone = phoneHref();
	const whatsapp = whatsappHref(pick(locale, copy.hero.signature));
	const instagram = instagramHref();
	const map = mapEmbedHref();
	const rows = [
		{
			label: pick(locale, copy.visit.address),
			value: configuredText(locale, salonConfig.address),
			empty: !isConfigured(salonConfig.address),
			href: null
		},
		{
			label: pick(locale, copy.visit.phone),
			value: salonConfig.phoneDisplay.trim() || configuredText(locale, {
				ar: "",
				en: ""
			}),
			empty: !phone,
			href: phone
		},
		{
			label: pick(locale, copy.visit.hours),
			value: configuredText(locale, salonConfig.hours),
			empty: !isConfigured(salonConfig.hours),
			href: null
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "visit",
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-16 sm:px-10 lg:col-span-6 lg:px-16 lg:py-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: pick(locale, copy.visit.kicker)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display-lg mt-4",
							children: pick(locale, copy.visit.title)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-taupe",
							children: pick(locale, copy.visit.lead)
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-10",
						children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1 border-t border-line py-5 sm:grid-cols-[8rem_1fr] sm:gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-sm text-taupe",
								children: row.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: row.empty ? "text-taupe" : "text-ink",
								children: row.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: row.href,
									className: "border-b border-ink",
									children: row.value
								}) : row.value
							})]
						}, row.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/book",
								className: "btn btn-solid",
								children: pick(locale, copy.visit.book)
							}),
							whatsapp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "btn btn-line",
								href: whatsapp,
								target: "_blank",
								rel: "noreferrer",
								children: pick(locale, copy.visit.whatsapp)
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "btn btn-line cursor-default",
								children: pick(locale, copy.visit.whatsappMissing)
							}),
							instagram ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "btn btn-line",
								href: instagram,
								target: "_blank",
								rel: "noreferrer",
								children: pick(locale, copy.visit.instagram)
							}) : null
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative min-h-80 border-t border-line bg-cream lg:col-span-6 lg:border-s lg:border-t-0",
				children: map ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					title: pick(locale, copy.visit.mapTitle),
					src: map,
					className: "absolute inset-0 h-full w-full border-0",
					loading: "lazy",
					referrerPolicy: "no-referrer-when-downgrade"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-full min-h-80 flex-col justify-between p-8 sm:p-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: pick(locale, salonConfig.city)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display text-4xl",
							children: pick(locale, copy.visit.mapTitle)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-sm text-sm text-taupe",
							children: pick(locale, copy.visit.mapEmpty)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px w-24 bg-bronze" })
					]
				})
			})]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Story, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gallery, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Experience, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Visit, {})
		]
	});
}
//#endregion
export { Home as component };
