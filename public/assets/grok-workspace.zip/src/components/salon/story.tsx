import { copy, pick } from "@/lib/salon";
import { useLocale } from "@/lib/locale";
import { Reveal } from "@/components/salon/reveal";

export function Story() {
  const { locale } = useLocale();

  return (
    <section id="story" className="border-t border-line bg-cream">
      <div className="grid lg:grid-cols-12">
        <div className="px-5 py-16 sm:px-10 lg:col-span-7 lg:px-16 lg:py-24">
          <Reveal>
            <p className="kicker">{pick(locale, copy.story.kicker)}</p>
            <h2 className="display-lg mt-4 max-w-xl">{pick(locale, copy.story.title)}</h2>
            <p className="mt-6 max-w-xl text-lg">{pick(locale, copy.story.body)}</p>
          </Reveal>
          <ol className="mt-12 grid gap-8 border-t border-line pt-8 md:grid-cols-3">
            {copy.story.points.map((point, index) => (
              <li key={point.title.en}>
                <Reveal delay={index * 80}>
                  <p className="display text-3xl text-bronze tabular-nums">0{index + 1}</p>
                  <h3 className="mt-3 text-lg font-medium">{pick(locale, point.title)}</h3>
                  <p className="mt-2 text-sm text-taupe">{pick(locale, point.text)}</p>
                </Reveal>
              </li>
            ))}
          </ol>
        </div>
        <figure className="relative min-h-80 lg:col-span-5">
          <img
            src="/images/mirrors.jpg"
            alt={pick(locale, {
              ar: "كراسي التصفيف أمام مرآة الصالون",
              en: "Styling chairs in front of the salon mirror",
            })}
            className="absolute inset-0 h-full w-full object-cover"
            loading="lazy"
            decoding="async"
          />
        </figure>
      </div>
    </section>
  );
}
