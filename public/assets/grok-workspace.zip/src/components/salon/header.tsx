import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { copy, pick, salonConfig } from "@/lib/salon";
import { useLocale } from "@/lib/locale";
import { cn } from "@/lib/cn";

const links = [
  { href: "/#services", key: "services" },
  { href: "/#story", key: "story" },
  { href: "/#gallery", key: "gallery" },
  { href: "/#visit", key: "visit" },
] as const;

export function Header() {
  const { locale, toggle } = useLocale();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header
      className={cn(
        "sticky top-0 z-40 border-b bg-ivory/92 backdrop-blur-md",
        scrolled ? "border-ink/20" : "border-line",
      )}
    >
      <a href="#content" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:m-3 focus:bg-paper focus:px-3 focus:py-2">
        {pick(locale, copy.skip)}
      </a>
      <div className="shell-wide flex items-center justify-between gap-4 py-3">
        <Link to="/" className="flex flex-col leading-none" aria-label={pick(locale, copy.hero.signature)}>
          <span className="kicker">{pick(locale, salonConfig.atelier)}</span>
          <span className="display text-3xl">{pick(locale, salonConfig.brand)}</span>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex" aria-label={pick(locale, copy.nav.menu)}>
          {links.map((link) => (
            <a key={link.key} href={link.href} className="text-sm text-ink transition-colors hover:text-bronze">
              {pick(locale, copy.nav[link.key])}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2 sm:gap-3">
          <button type="button" onClick={toggle} className="btn btn-ghost px-2 text-sm" aria-label={pick(locale, copy.nav.language)}>
            {pick(locale, copy.nav.language)}
          </button>
          <Link to="/book" className="btn btn-solid hidden sm:inline-flex">
            {pick(locale, copy.nav.book)}
          </Link>
          <Link to="/book" className="btn btn-solid sm:hidden">
            {pick(locale, copy.nav.bookShort)}
          </Link>
          <button
            type="button"
            className="btn btn-line px-3 lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            onClick={() => setOpen((value) => !value)}
          >
            {open ? pick(locale, copy.nav.close) : pick(locale, copy.nav.menu)}
          </button>
        </div>
      </div>

      <div
        id="mobile-nav"
        className={cn(
          "fixed inset-0 z-50 flex flex-col bg-ivory px-6 pb-10 pt-6 transition-opacity duration-200 lg:hidden",
          open ? "visible opacity-100" : "invisible pointer-events-none opacity-0",
        )}
        hidden={!open}
      >
        <div className="flex items-center justify-between">
          <span className="display text-3xl">{pick(locale, salonConfig.brand)}</span>
          <button type="button" className="btn btn-line" onClick={() => setOpen(false)}>
            {pick(locale, copy.nav.close)}
          </button>
        </div>
        <nav className="mt-12 flex flex-col gap-6" aria-label={pick(locale, copy.nav.menu)}>
          {links.map((link) => (
            <a
              key={link.key}
              href={link.href}
              onClick={() => setOpen(false)}
              className="display text-4xl"
            >
              {pick(locale, copy.nav[link.key])}
            </a>
          ))}
        </nav>
        <div className="mt-auto flex flex-col gap-3">
          <Link to="/book" className="btn btn-solid w-full" onClick={() => setOpen(false)}>
            {pick(locale, copy.nav.book)}
          </Link>
          <button type="button" className="btn btn-line w-full" onClick={toggle}>
            {pick(locale, copy.nav.language)}
          </button>
        </div>
      </div>
    </header>
  );
}
