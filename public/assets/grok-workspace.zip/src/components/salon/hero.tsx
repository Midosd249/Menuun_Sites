import { Link } from "@tanstack/react-router";
import { copy, pick, salonConfig } from "@/lib/salon";
import { useLocale } from "@/lib/locale";

export function Hero() {
  const { locale } = useLocale();

  return (
    <section className="grid lg:min-h-[calc(100svh-5.25rem)] lg:grid-cols-12">
      <div className="hero-media relative lg:col-span-7">
        <img
          src="/images/hero.jpg"
          alt={pick(locale, {
            ar: "مصففة تصفف الشعر داخل صالون مضيء",
            en: "A stylist finishing hair in a bright salon",
          })}
          className="absolute inset-0 h-full w-full object-cover"
          fetchPriority="high"
          decoding="async"
        />
        <p className="absolute bottom-4 start-4 bg-espresso px-3 py-2 text-xs text-paper">
          {pick(locale, copy.hero.caption)}
        </p>
      </div>
      <div className="flex flex-col justify-between gap-10 bg-paper px-5 py-10 sm:px-10 lg:col-span-5 lg:px-12 lg:py-14">
        <p className="kicker hero-rise">{pick(locale, copy.hero.kicker)}</p>
        <div className="flex flex-col gap-6">
          <h1 className="display-xl hero-rise delay-1">{pick(locale, copy.hero.title)}</h1>
          <p className="max-w-md text-base text-ink/80 hero-rise delay-2 sm:text-lg">
            {pick(locale, copy.hero.lead)}
          </p>
          <div className="flex flex-col gap-3 hero-rise delay-3 sm:flex-row">
            <Link to="/book" className="btn btn-solid">
              {pick(locale, copy.hero.primary)}
            </Link>
            <a href="#services" className="btn btn-line">
              {pick(locale, copy.hero.secondary)}
            </a>
          </div>
        </div>
        <p className="flex items-center justify-between gap-4 border-t border-line pt-5 text-sm text-taupe hero-rise delay-4">
          <span className="display text-2xl text-ink">{pick(locale, salonConfig.brand)}</span>
          <span>{pick(locale, salonConfig.city)}</span>
        </p>
      </div>
    </section>
  );
}
