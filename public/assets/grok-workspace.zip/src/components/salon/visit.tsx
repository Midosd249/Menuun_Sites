import { Link } from "@tanstack/react-router";
import {
  configuredText,
  copy,
  instagramHref,
  isConfigured,
  mapEmbedHref,
  phoneHref,
  pick,
  salonConfig,
  whatsappHref,
} from "@/lib/salon";
import { useLocale } from "@/lib/locale";
import { Reveal } from "@/components/salon/reveal";

export function Visit() {
  const { locale } = useLocale();
  const phone = phoneHref();
  const whatsapp = whatsappHref(pick(locale, copy.hero.signature));
  const instagram = instagramHref();
  const map = mapEmbedHref();

  const rows = [
    {
      label: pick(locale, copy.visit.address),
      value: configuredText(locale, salonConfig.address),
      empty: !isConfigured(salonConfig.address),
      href: null as string | null,
    },
    {
      label: pick(locale, copy.visit.phone),
      value: salonConfig.phoneDisplay.trim() || configuredText(locale, { ar: "", en: "" }),
      empty: !phone,
      href: phone,
    },
    {
      label: pick(locale, copy.visit.hours),
      value: configuredText(locale, salonConfig.hours),
      empty: !isConfigured(salonConfig.hours),
      href: null,
    },
  ];

  return (
    <section id="visit" className="border-t border-line">
      <div className="grid lg:grid-cols-12">
        <div className="px-5 py-16 sm:px-10 lg:col-span-6 lg:px-16 lg:py-24">
          <Reveal>
            <p className="kicker">{pick(locale, copy.visit.kicker)}</p>
            <h2 className="display-lg mt-4">{pick(locale, copy.visit.title)}</h2>
            <p className="mt-5 max-w-xl text-taupe">{pick(locale, copy.visit.lead)}</p>
          </Reveal>
          <dl className="mt-10">
            {rows.map((row) => (
              <div key={row.label} className="grid gap-1 border-t border-line py-5 sm:grid-cols-[8rem_1fr] sm:gap-6">
                <dt className="text-sm text-taupe">{row.label}</dt>
                <dd className={row.empty ? "text-taupe" : "text-ink"}>
                  {row.href ? (
                    <a href={row.href} className="border-b border-ink">
                      {row.value}
                    </a>
                  ) : (
                    row.value
                  )}
                </dd>
              </div>
            ))}
          </dl>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <Link to="/book" className="btn btn-solid">
              {pick(locale, copy.visit.book)}
            </Link>
            {whatsapp ? (
              <a className="btn btn-line" href={whatsapp} target="_blank" rel="noreferrer">
                {pick(locale, copy.visit.whatsapp)}
              </a>
            ) : (
              <p className="btn btn-line cursor-default">{pick(locale, copy.visit.whatsappMissing)}</p>
            )}
            {instagram ? (
              <a className="btn btn-line" href={instagram} target="_blank" rel="noreferrer">
                {pick(locale, copy.visit.instagram)}
              </a>
            ) : null}
          </div>
        </div>
        <div className="relative min-h-80 border-t border-line bg-cream lg:col-span-6 lg:border-s lg:border-t-0">
          {map ? (
            <iframe
              title={pick(locale, copy.visit.mapTitle)}
              src={map}
              className="absolute inset-0 h-full w-full border-0"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          ) : (
            <div className="flex h-full min-h-80 flex-col justify-between p-8 sm:p-12">
              <p className="kicker">{pick(locale, salonConfig.city)}</p>
              <div>
                <p className="display text-4xl">{pick(locale, copy.visit.mapTitle)}</p>
                <p className="mt-4 max-w-sm text-sm text-taupe">{pick(locale, copy.visit.mapEmpty)}</p>
              </div>
              <div className="h-px w-24 bg-bronze" />
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
