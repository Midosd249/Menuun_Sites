import { useEffect, useId, useRef, useState } from "react";
import { copy, gallery, pick } from "@/lib/salon";
import { useLocale } from "@/lib/locale";
import { cn } from "@/lib/cn";
import { Reveal } from "@/components/salon/reveal";

export function Gallery() {
  const { locale } = useLocale();
  const [active, setActive] = useState<number | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const titleId = useId();

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (active === null) {
      if (dialog.open) dialog.close();
      return;
    }
    if (!dialog.open) dialog.showModal();
  }, [active]);

  const current = active === null ? null : gallery[active];

  function step(direction: -1 | 1) {
    setActive((index) => {
      if (index === null) return index;
      return (index + direction + gallery.length) % gallery.length;
    });
  }

  return (
    <section id="gallery" className="border-t border-line">
      <div className="shell py-16 md:py-24">
        <Reveal>
          <p className="kicker">{pick(locale, copy.gallery.kicker)}</p>
          <div className="mt-4 flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <h2 className="display-lg max-w-xl">{pick(locale, copy.gallery.title)}</h2>
            <p className="max-w-sm text-sm text-taupe">{pick(locale, copy.gallery.lead)}</p>
          </div>
        </Reveal>
        <div className="gallery-bento mt-10">
          {gallery.map((item, index) => (
            <figure key={item.id} className={cn("tile", `t${index + 1}`)}>
              <button
                type="button"
                className="media-zoom absolute inset-0 block h-full w-full text-start"
                onClick={() => setActive(index)}
              >
                <img
                  src={item.image}
                  alt={pick(locale, item.alt)}
                  className="h-full w-full object-cover"
                  loading="lazy"
                  decoding="async"
                />
                <span className="sr-only">{pick(locale, copy.gallery.open)}</span>
              </button>
              <figcaption className="pointer-events-none absolute inset-x-0 bottom-0 bg-espresso/95 px-3 py-2 text-xs text-paper">
                {pick(locale, item.caption)}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>

      <dialog
        ref={dialogRef}
        aria-labelledby={titleId}
        className="m-auto w-[min(68rem,calc(100%-1.5rem))] border-0 bg-transparent p-0 backdrop:bg-espresso/80"
        onClose={() => setActive(null)}
        onClick={(event) => {
          if (event.target === dialogRef.current) setActive(null);
        }}
      >
        {current ? (
          <div className="bg-espresso text-paper">
            <div className="flex items-center justify-between gap-4 px-4 py-3">
              <p id={titleId} className="text-sm">
                {pick(locale, current.caption)}
              </p>
              <button type="button" className="btn btn-paper" onClick={() => setActive(null)}>
                {pick(locale, copy.gallery.close)}
              </button>
            </div>
            <img
              src={current.image}
              alt={pick(locale, current.alt)}
              className="max-h-[72vh] w-full object-contain bg-ink"
            />
            <div className="flex justify-between gap-3 px-4 py-3">
              <button type="button" className="btn btn-paper" onClick={() => step(-1)}>
                {pick(locale, copy.gallery.prev)}
              </button>
              <button type="button" className="btn btn-paper" onClick={() => step(1)}>
                {pick(locale, copy.gallery.next)}
              </button>
            </div>
          </div>
        ) : null}
      </dialog>
    </section>
  );
}
