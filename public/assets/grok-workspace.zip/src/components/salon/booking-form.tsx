import { useMemo, useState, type FormEvent } from "react";
import { cn } from "@/lib/cn";
import { useLocale } from "@/lib/locale";
import {
  copy,
  pick,
  serviceById,
  services,
  timeSlots,
  whatsappHref,
  type Service,
} from "@/lib/salon";

type Field = "service" | "name" | "phone" | "date" | "time";

type StoredRequest = {
  id: string;
  serviceId: string;
  name: string;
  phone: string;
  date: string;
  time: string;
};

const STORAGE_KEY = "layan-demo-requests";

function isoOffset(days: number) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60_000);
  return local.toISOString().slice(0, 10);
}

function validName(value: string) {
  const trimmed = value.trim();
  return /^[\p{L}\s'.-]{2,60}$/u.test(trimmed);
}

function validPhone(value: string) {
  const compact = value.replace(/[\s-]/g, "");
  return /^(?:\+?966|0)?5\d{8}$/.test(compact);
}

function loadRequests(): StoredRequest[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as StoredRequest[];
    return Array.isArray(parsed) ? parsed.slice(0, 6) : [];
  } catch {
    return [];
  }
}

export function BookingForm({ initialServiceId }: { initialServiceId?: string }) {
  const { locale } = useLocale();
  const initial = serviceById(initialServiceId)?.id ?? services[0]?.id ?? "";
  const [serviceId, setServiceId] = useState(initial);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [errors, setErrors] = useState<Partial<Record<Field, string>>>({});
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState<StoredRequest | null>(null);
  const [history, setHistory] = useState<StoredRequest[]>([]);

  const minDate = useMemo(() => isoOffset(0), []);
  const maxDate = useMemo(() => isoOffset(60), []);
  const selected = serviceById(serviceId) ?? services[0];

  function validate() {
    const next: Partial<Record<Field, string>> = {};
    if (!serviceById(serviceId)) next.service = pick(locale, copy.book.errors.service);
    if (!validName(name)) next.name = pick(locale, copy.book.errors.name);
    if (!validPhone(phone)) next.phone = pick(locale, copy.book.errors.phone);
    if (!date || date < minDate || date > maxDate) next.date = pick(locale, copy.book.errors.date);
    if (!timeSlots.includes(time)) next.time = pick(locale, copy.book.errors.time);
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!validate()) return;
    setSending(true);
    await new Promise((resolve) => window.setTimeout(resolve, 450));
    const request: StoredRequest = {
      id: `LY-${Date.now().toString(36).toUpperCase().slice(-6)}`,
      serviceId,
      name: name.trim(),
      phone: phone.replace(/[\s-]/g, ""),
      date,
      time,
    };
    const nextHistory = [request, ...loadRequests()].slice(0, 6);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(nextHistory));
    setHistory(nextHistory);
    setDone(request);
    setSending(false);
  }

  function reset() {
    setDone(null);
    setName("");
    setPhone("");
    setDate("");
    setTime("");
    setErrors({});
  }

  const whatsapp = done
    ? whatsappHref(
        locale === "ar"
          ? `مرحباً، لدي طلب تجريبي ${done.id} لخدمة ${pick(locale, selected?.name ?? services[0].name)} يوم ${done.date} الساعة ${done.time}. الاسم: ${done.name}.`
          : `Hello, this is demo request ${done.id} for ${pick(locale, selected?.name ?? services[0].name)} on ${done.date} at ${done.time}. Name: ${done.name}.`,
      )
    : null;

  return (
    <div className="grid lg:grid-cols-12">
      <aside className="order-2 bg-espresso px-5 py-12 text-paper sm:px-10 lg:order-2 lg:col-span-5 lg:px-12 lg:py-16">
        <p className="kicker text-bronze-soft">{pick(locale, copy.book.kicker)}</p>
        <h1 className="display-lg mt-4">{pick(locale, copy.book.title)}</h1>
        <p className="mt-5 max-w-md text-sm leading-7 text-paper/75">{pick(locale, copy.book.lead)}</p>
        {selected ? <ServicePreview locale={locale} service={selected} /> : null}
      </aside>

      <div className="order-1 px-5 py-12 sm:px-10 lg:order-1 lg:col-span-7 lg:px-12 lg:py-16">
        {done ? (
          <div role="status" className="max-w-xl">
            <p className="kicker">{done.id}</p>
            <h2 className="display-lg mt-3">{pick(locale, copy.book.successTitle)}</h2>
            <p className="mt-4 text-taupe">{pick(locale, copy.book.successBody)}</p>
            <dl className="mt-8 border-t border-line text-sm">
              <SummaryRow label={pick(locale, copy.book.reference)} value={done.id} />
              <SummaryRow label={pick(locale, copy.book.service)} value={pick(locale, selected?.name ?? services[0].name)} />
              <SummaryRow label={pick(locale, copy.book.name)} value={done.name} />
              <SummaryRow label={pick(locale, copy.book.phone)} value={done.phone} ltr />
              <SummaryRow label={pick(locale, copy.book.date)} value={done.date} ltr />
              <SummaryRow label={pick(locale, copy.book.time)} value={done.time} ltr />
            </dl>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <button type="button" className="btn btn-solid" onClick={reset}>
                {pick(locale, copy.book.another)}
              </button>
              {whatsapp ? (
                <a className="btn btn-line" href={whatsapp} target="_blank" rel="noreferrer">
                  {pick(locale, copy.book.whatsappCta)}
                </a>
              ) : null}
            </div>
            {history.length > 1 ? (
              <p className="mt-8 text-xs text-taupe">
                {locale === "ar"
                  ? `${history.length} طلبات تجريبية محفوظة على هذا الجهاز.`
                  : `${history.length} demo requests saved on this device.`}
              </p>
            ) : null}
          </div>
        ) : (
          <form className="max-w-xl" onSubmit={onSubmit} noValidate>
            <fieldset>
              <legend className="text-sm font-medium">{pick(locale, copy.book.service)}</legend>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {services.map((service) => {
                  const active = service.id === serviceId;
                  return (
                    <label
                      key={service.id}
                      className={cn(
                        "flex min-h-12 cursor-pointer items-center border px-3 text-sm transition-colors",
                        active ? "border-ink bg-ink text-paper" : "border-line bg-paper text-ink hover:border-ink",
                      )}
                    >
                      <input
                        type="radio"
                        name="service"
                        value={service.id}
                        checked={active}
                        onChange={() => setServiceId(service.id)}
                        className="sr-only"
                      />
                      {pick(locale, service.name)}
                    </label>
                  );
                })}
              </div>
              {errors.service ? <FieldError message={errors.service} /> : null}
            </fieldset>

            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              <label className="block">
                <span className="text-sm font-medium">{pick(locale, copy.book.name)}</span>
                <input
                  className="field"
                  name="name"
                  autoComplete="name"
                  value={name}
                  placeholder={pick(locale, copy.book.namePh)}
                  aria-invalid={Boolean(errors.name)}
                  onChange={(event) => setName(event.target.value)}
                />
                {errors.name ? <FieldError message={errors.name} /> : null}
              </label>
              <label className="block">
                <span className="text-sm font-medium">{pick(locale, copy.book.phone)}</span>
                <input
                  className="field"
                  name="tel"
                  type="tel"
                  inputMode="tel"
                  autoComplete="tel"
                  dir="ltr"
                  value={phone}
                  placeholder={pick(locale, copy.book.phonePh)}
                  aria-invalid={Boolean(errors.phone)}
                  onChange={(event) => setPhone(event.target.value)}
                />
                {errors.phone ? <FieldError message={errors.phone} /> : null}
              </label>
            </div>

            <label className="mt-8 block">
              <span className="text-sm font-medium">{pick(locale, copy.book.date)}</span>
              <input
                className="field"
                type="date"
                name="date"
                dir="ltr"
                min={minDate}
                max={maxDate}
                value={date}
                aria-invalid={Boolean(errors.date)}
                onChange={(event) => setDate(event.target.value)}
              />
              {errors.date ? <FieldError message={errors.date} /> : null}
            </label>

            <fieldset className="mt-8">
              <legend className="text-sm font-medium">{pick(locale, copy.book.time)}</legend>
              <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-4">
                {timeSlots.map((slot) => {
                  const active = slot === time;
                  return (
                    <button
                      key={slot}
                      type="button"
                      aria-pressed={active}
                      onClick={() => setTime(slot)}
                      className={cn(
                        "min-h-11 border text-sm tabular-nums transition-colors",
                        active ? "border-ink bg-ink text-paper" : "border-line bg-paper hover:border-ink",
                      )}
                    >
                      {slot}
                    </button>
                  );
                })}
              </div>
              {errors.time ? <FieldError message={errors.time} /> : null}
            </fieldset>

            <button type="submit" className="btn btn-solid mt-10 w-full sm:w-auto" disabled={sending}>
              {sending ? pick(locale, copy.book.sending) : pick(locale, copy.book.submit)}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

function ServicePreview({ locale, service }: { locale: "ar" | "en"; service: Service }) {
  return (
    <figure className="mt-10">
      <div className="relative aspect-[5/4] overflow-hidden">
        <img
          src={service.image}
          alt={pick(locale, service.alt)}
          className="absolute inset-0 h-full w-full object-cover"
        />
      </div>
      <figcaption className="mt-4">
        <p className="display text-3xl">{pick(locale, service.name)}</p>
        <p className="mt-2 text-sm text-paper/70">
          {pick(locale, service.duration)} · {pick(locale, service.price)}
        </p>
      </figcaption>
    </figure>
  );
}

function SummaryRow({ label, value, ltr = false }: { label: string; value: string; ltr?: boolean }) {
  return (
    <div className="grid gap-1 border-b border-line py-3 sm:grid-cols-[9rem_1fr]">
      <dt className="text-taupe">{label}</dt>
      <dd dir={ltr ? "ltr" : undefined} className={ltr ? "text-start" : undefined}>
        {value}
      </dd>
    </div>
  );
}

function FieldError({ message }: { message: string }) {
  return (
    <p role="alert" className="mt-2 text-sm text-bronze">
      {message}
    </p>
  );
}
