import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/cn";
import { useLocale } from "@/lib/locale";
import { copy, pick, services } from "@/lib/salon";
import { Reveal } from "@/components/salon/reveal";

export function Services() {
  const { locale } = useLocale();

  return (
    <section id="services" className="border-t border-line">
      <div className="shell py-16 md:py-24">
        <Reveal>
          <p className="kicker">{pick(locale, copy.services.kicker)}</p>
          <h2 className="display-lg mt-4 max-w-3xl">{pick(locale, copy.services.title)}</h2>
          <p className="mt-5 max-w-2xl text-taupe">{pick(locale, copy.services.lead)}</p>
        </Reveal>
        <nav className="mt-8 flex flex-wrap gap-x-6 gap-y-3" aria-label={pick(locale, copy.nav.services)}>
          {services.map((service) => (
            <a key={service.id} href={`#service-${service.id}`} className="border-b border-transparent text-sm hover:border-bronze">
              {pick(locale, service.name)}
            </a>
          ))}
        </nav>
      </div>

      <div>
        {services.map((service, index) => {
          const flip = index % 2 === 1;
          return (
            <article
              id={`service-${service.id}`}
              key={service.id}
              className="grid border-t border-line lg:grid-cols-12"
            >
              <figure
                className={cn(
                  "service-media group media-zoom relative overflow-hidden bg-cream lg:col-span-5",
                  flip && "lg:col-start-8",
                )}
              >
                <img
                  src={service.image}
                  alt={pick(locale, service.alt)}
                  className="absolute inset-0 h-full w-full object-cover"
                  loading="lazy"
                  decoding="async"
                />
              </figure>
              <div
                className={cn(
                  "flex flex-col justify-center gap-5 px-5 py-10 sm:px-10 lg:col-span-7 lg:px-16 lg:py-16",
                  flip && "lg:col-start-1 lg:row-start-1",
                )}
              >
                <p className="kicker tabular-nums">0{index + 1}</p>
                <h3 className="display text-4xl sm:text-5xl">{pick(locale, service.name)}</h3>
                <p className="max-w-xl text-ink/85">{pick(locale, service.summary)}</p>
                <p className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-taupe">
                  <span>{pick(locale, service.duration)}</span>
                  <span aria-hidden="true">·</span>
                  <span>{pick(locale, service.price)}</span>
                  <span aria-hidden="true">·</span>
                  <span>{pick(locale, copy.services.illustrative)}</span>
                </p>
                <Link to="/book" search={{ service: service.id }} className="btn btn-ghost w-fit border-b border-ink px-0">
                  {pick(locale, copy.services.book)}
                </Link>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
