import { Link } from "@tanstack/react-router";
import { copy, instagramHref, phoneHref, pick, salonConfig, whatsappHref } from "@/lib/salon";
import { useLocale } from "@/lib/locale";

export function Footer() {
  const { locale } = useLocale();
  const year = new Date().getFullYear();
  const phone = phoneHref();
  const whatsapp = whatsappHref(pick(locale, copy.hero.signature));
  const instagram = instagramHref();

  return (
    <footer className="border-t border-ink bg-ivory">
      <div className="shell-wide grid gap-10 py-14 md:grid-cols-[1.4fr_1fr_1fr] md:py-16">
        <div>
          <p className="kicker">{pick(locale, salonConfig.atelier)}</p>
          <p className="display mt-2 text-5xl">{pick(locale, salonConfig.brand)}</p>
          <p className="mt-4 max-w-sm text-sm text-taupe">{pick(locale, copy.footer.line)}</p>
        </div>
        <nav className="flex flex-col gap-3 text-sm" aria-label={pick(locale, copy.nav.menu)}>
          <a href="/#services">{pick(locale, copy.nav.services)}</a>
          <a href="/#story">{pick(locale, copy.nav.story)}</a>
          <a href="/#gallery">{pick(locale, copy.nav.gallery)}</a>
          <a href="/#visit">{pick(locale, copy.nav.visit)}</a>
        </nav>
        <div className="flex flex-col items-start gap-3">
          <Link to="/book" className="btn btn-solid">
            {pick(locale, copy.nav.book)}
          </Link>
          {phone ? (
            <a href={phone} className="text-sm">
              {salonConfig.phoneDisplay}
            </a>
          ) : null}
          {whatsapp ? (
            <a href={whatsapp} className="text-sm" target="_blank" rel="noreferrer">
              {pick(locale, copy.visit.whatsapp)}
            </a>
          ) : null}
          {instagram ? (
            <a href={instagram} className="text-sm" target="_blank" rel="noreferrer">
              {pick(locale, copy.visit.instagram)}
            </a>
          ) : null}
        </div>
      </div>
      <div className="shell-wide flex flex-col gap-2 border-t border-line py-5 text-xs text-taupe sm:flex-row sm:items-center sm:justify-between">
        <p>
          © {year} {pick(locale, copy.hero.signature)}. {pick(locale, copy.footer.rights)}
        </p>
        <p>{pick(locale, copy.footer.photos)}</p>
      </div>
    </footer>
  );
}
