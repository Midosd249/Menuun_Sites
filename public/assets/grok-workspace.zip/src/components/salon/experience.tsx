import { Link } from "@tanstack/react-router";
import { copy, pick } from "@/lib/salon";
import { useLocale } from "@/lib/locale";
import { Reveal } from "@/components/salon/reveal";

export function Experience() {
  const { locale } = useLocale();

  return (
    <section className="bg-espresso text-paper">
      <div className="shell py-16 md:py-24">
        <Reveal>
          <p className="kicker text-bronze-soft">{pick(locale, copy.experience.kicker)}</p>
          <h2 className="display-lg mt-4 max-w-3xl">{pick(locale, copy.experience.title)}</h2>
        </Reveal>
        <ol className="mt-12 grid gap-10 md:grid-cols-3">
          {copy.experience.steps.map((step, index) => (
            <li key={step.title.en} className="border-t border-paper/15 pt-6">
              <Reveal delay={index * 90}>
                <p className="display text-4xl text-bronze-soft tabular-nums">0{index + 1}</p>
                <h3 className="mt-4 text-xl font-medium">{pick(locale, step.title)}</h3>
                <p className="mt-3 text-sm leading-7 text-paper/80">{pick(locale, step.text)}</p>
              </Reveal>
            </li>
          ))}
        </ol>
        <Reveal>
          <Link to="/book" className="btn btn-paper mt-12">
            {pick(locale, copy.nav.book)}
          </Link>
        </Reveal>
      </div>
    </section>
  );
}
