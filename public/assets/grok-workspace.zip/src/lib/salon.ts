export type Locale = "ar" | "en";

/**
 * Demo salon identity. Replace these values when customizing for a real client.
 * Leave unknown contact fields empty — the site shows a clear placeholder
 * instead of inventing an address, phone, or map pin.
 */
export const salonConfig = {
  brand: { ar: "ليان", en: "Layan" },
  atelier: { ar: "أتيليه", en: "Atelier" },
  city: { ar: "الرياض", en: "Riyadh" },
  /** Digits only, country code included, no plus. Example: 9665XXXXXXXX */
  whatsappE164: "",
  /** Shown to visitors. Example: +966 5X XXX XXXX */
  phoneDisplay: "",
  address: { ar: "", en: "" },
  hours: { ar: "", en: "" },
  /** https://instagram.com/... — leave empty to hide the link */
  instagramUrl: "",
  /** https maps embed URL — leave empty to show the map placeholder */
  mapEmbedUrl: "",
};

export type Localized = Record<Locale, string>;

export type Service = {
  id: string;
  image: string;
  name: Localized;
  summary: Localized;
  duration: Localized;
  price: Localized;
  alt: Localized;
};

export const services: Service[] = [
  {
    id: "styling",
    image: "/images/hair.jpg",
    name: { ar: "تصفيف الشعر", en: "Hair styling" },
    summary: {
      ar: "قصّة أو تسريحة أو لمسة أخيرة قبل خروجك. نبدأ بشكل الشعر وما يناسب يومك.",
      en: "A cut, a finish, or a look for later today. We start with your hair and the day you have in mind.",
    },
    duration: { ar: "٤٥–٧٥ دقيقة", en: "45–75 min" },
    price: { ar: "من ١٨٠ ر.س", en: "from SAR 180" },
    alt: {
      ar: "مصففة تجفف الشعر بفرشاة دائرية داخل الصالون",
      en: "A stylist blow-drying hair with a round brush",
    },
  },
  {
    id: "color",
    image: "/images/color.jpg",
    name: { ar: "تلوين الشعر", en: "Hair color" },
    summary: {
      ar: "لون كامل أو خصلات أخف، بعد حديث عن الدرجة والعناية التي تليها.",
      en: "A full color or a lighter placement, after we talk through the tone and the care that follows.",
    },
    duration: { ar: "٩٠–١٥٠ دقيقة", en: "90–150 min" },
    price: { ar: "من ٣٢٠ ر.س", en: "from SAR 320" },
    alt: {
      ar: "شطف الشعر بهدوء بعد جلسة عناية في حوض الغسيل",
      en: "Hair being rinsed at a salon basin",
    },
  },
  {
    id: "manicure",
    image: "/images/manicure.jpg",
    name: { ar: "عناية الأظافر", en: "Nail care" },
    summary: {
      ar: "مانيكير وباديكير بتشذيب نظيف ولون هادئ، من غير استعجال.",
      en: "A manicure and pedicure with a clean shape and a quiet color, unhurried.",
    },
    duration: { ar: "٤٥–٧٠ دقيقة", en: "45–70 min" },
    price: { ar: "من ١٢٠ ر.س", en: "from SAR 120" },
    alt: {
      ar: "يدان بأظافر مطلية بلون وردي هادئ",
      en: "Hands with a soft pink manicure",
    },
  },
  {
    id: "nailart",
    image: "/images/nails.jpg",
    name: { ar: "رسم الأظافر", en: "Nail art" },
    summary: {
      ar: "نقش خفيف أو لمسة أوضح. تختارين الدرجة، وننفّذها بدقة.",
      en: "A faint pattern or a clearer gesture. You choose the tone; we place it carefully.",
    },
    duration: { ar: "٦٠–٩٠ دقيقة", en: "60–90 min" },
    price: { ar: "من ١٦٠ ر.س", en: "from SAR 160" },
    alt: {
      ar: "أظافر بطلاء أسود لامع ونقش كهرماني",
      en: "Glossy black nails with an amber tortoiseshell accent",
    },
  },
  {
    id: "skin",
    image: "/images/facial.jpg",
    name: { ar: "عناية البشرة", en: "Skin care" },
    summary: {
      ar: "جلسة تنظيف وعناية بالوجه. راحة وخطوات واضحة، من غير وعود طبية.",
      en: "A facial of cleansing and care. Rest, and a clear sequence — not a medical promise.",
    },
    duration: { ar: "٥٠–٧٥ دقيقة", en: "50–75 min" },
    price: { ar: "من ٢٢٠ ر.س", en: "from SAR 220" },
    alt: {
      ar: "وضع قناع عناية على بشرة الوجه داخل الجلسة",
      en: "A clay mask being applied during a facial",
    },
  },
  {
    id: "bridal",
    image: "/images/portrait.jpg",
    name: { ar: "إطلالة العروس", en: "Bridal beauty" },
    summary: {
      ar: "شعر ومكياج ليوم الزفاف. نرتّب الوقت مسبقاً، والسعر يُحدَّد بعد الاستشارة.",
      en: "Hair and makeup for the wedding day. Time is arranged ahead, and the fee follows a consultation.",
    },
    duration: { ar: "حسب الترتيب", en: "By arrangement" },
    price: { ar: "بعد الاستشارة", en: "After consultation" },
    alt: {
      ar: "لقطة قريبة لوضع أحمر الشفاه ضمن مكياج العناية",
      en: "A close view of lipstick being applied",
    },
  },
];

export type GalleryItem = {
  id: string;
  image: string;
  alt: Localized;
  caption: Localized;
  wide?: boolean;
  tall?: boolean;
};

export const gallery: GalleryItem[] = [
  {
    id: "wash",
    image: "/images/stylist.jpg",
    tall: true,
    alt: { ar: "غسل الشعر في حوض الصالون", en: "Hair being washed at the salon basin" },
    caption: { ar: "غسل الشعر", en: "Hair wash" },
  },
  {
    id: "studio",
    image: "/images/interior.jpg",
    wide: true,
    alt: { ar: "صالة تصفيف بإضاءة النهار والمرايا", en: "Styling floor with daylight and mirrors" },
    caption: { ar: "صالة التصفيف", en: "The floor" },
  },
  {
    id: "nails-session",
    image: "/images/nailart.jpg",
    alt: { ar: "أخصائية تنهي العناية بطرف الظفر", en: "A nail artist finishing the tip of a nail" },
    caption: { ar: "جلسة الأظافر", en: "Nail session" },
  },
  {
    id: "polish",
    image: "/images/hands.jpg",
    alt: { ar: "أظافر بألوان رمادية وبيضاء هادئة", en: "Nails in quiet grey and white polish" },
    caption: { ar: "ألوان هادئة", en: "Quiet color" },
  },
  {
    id: "tools",
    image: "/images/soft.jpg",
    alt: { ar: "فرش مكياج في إناء معدني", en: "Makeup brushes standing in a metal cup" },
    caption: { ar: "أدوات المكياج", en: "Makeup tools" },
  },
  {
    id: "brow",
    image: "/images/brow.jpg",
    wide: true,
    alt: { ar: "تحديد الحاجب بخيط خلال جلسة عناية", en: "Brows being shaped with thread" },
    caption: { ar: "تحديد الحاجب", en: "Brow shaping" },
  },
];

export const timeSlots: string[] = Array.from({ length: 20 }, (_, index) => {
  const total = 11 * 60 + index * 30;
  const hours = Math.floor(total / 60);
  const minutes = total % 60;
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
});

export function serviceById(id: string | undefined) {
  return services.find((service) => service.id === id);
}

export function whatsappHref(message: string): string | null {
  const digits = salonConfig.whatsappE164.replace(/\D/g, "");
  if (!/^\d{8,15}$/.test(digits)) return null;
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}

export function phoneHref(): string | null {
  const compact = salonConfig.phoneDisplay.replace(/[^\d+]/g, "");
  if (compact.replace(/\D/g, "").length < 8) return null;
  return `tel:${compact}`;
}

export function instagramHref(): string | null {
  const value = salonConfig.instagramUrl.trim();
  if (!value.startsWith("https://")) return null;
  return value;
}

export function mapEmbedHref(): string | null {
  const value = salonConfig.mapEmbedUrl.trim();
  if (!value.startsWith("https://")) return null;
  try {
    const url = new URL(value);
    const host = url.hostname;
    const allowed =
      host === "www.google.com" ||
      host === "maps.google.com" ||
      host.endsWith(".google.com") ||
      host === "www.openstreetmap.org" ||
      host.endsWith(".openstreetmap.org");
    return allowed ? value : null;
  } catch {
    return null;
  }
}

const pending: Localized = {
  ar: "يُضاف عند التخصيص",
  en: "Added when you customize",
};

export function configuredText(locale: Locale, value: Localized) {
  const text = value[locale].trim();
  return text || pending[locale];
}

export function isConfigured(value: Localized) {
  return Boolean(value.ar.trim() || value.en.trim());
}

export const copy = {
  skip: { ar: "تخطّي إلى المحتوى", en: "Skip to content" },
  nav: {
    services: { ar: "الخدمات", en: "Services" },
    story: { ar: "القصة", en: "Story" },
    gallery: { ar: "المعرض", en: "Gallery" },
    visit: { ar: "الزيارة", en: "Visit" },
    book: { ar: "احجزي موعدك", en: "Book a visit" },
    bookShort: { ar: "احجزي", en: "Book" },
    menu: { ar: "القائمة", en: "Menu" },
    close: { ar: "إغلاق", en: "Close" },
    language: { ar: "English", en: "العربية" },
  },
  hero: {
    kicker: { ar: "صالون نسائي في الرياض", en: "A women’s salon in Riyadh" },
    title: { ar: "حيث تُصاغ التفاصيل بهدوء", en: "Where detail is shaped in quiet" },
    lead: {
      ar: "عناية بالشعر والبشرة والأظافر. جلسة على مهلك، تبدأ بسؤال قصير: ماذا تريدين اليوم؟",
      en: "Care for hair, skin, and nails. An unhurried session that starts with a short question: what do you want today?",
    },
    primary: { ar: "احجزي موعدك", en: "Book a visit" },
    secondary: { ar: "استعرضي الخدمات", en: "View services" },
    caption: { ar: "تصفيف داخل الصالون", en: "Styling, in the salon" },
    signature: { ar: "أتيليه ليان", en: "Atelier Layan" },
  },
  services: {
    kicker: { ar: "القائمة", en: "The list" },
    title: { ar: "ست خدمات، بلا ازدحام", en: "Six services, uncluttered" },
    lead: {
      ar: "كل باب يفتح على طلب حجز. المدد والأسعار أمثلة للعرض، وتُستبدل بقائمة الصالون الفعلية.",
      en: "Each one opens a booking request. Durations and prices are examples for this demo, ready to be replaced.",
    },
    book: { ar: "اطلبي هذه الخدمة", en: "Request this service" },
    illustrative: { ar: "سعر توضيحي", en: "Illustrative price" },
  },
  story: {
    kicker: { ar: "القصة", en: "The house" },
    title: { ar: "نبدأ بالسؤال، لا بالمقص", en: "We begin with a question, not the scissors" },
    body: {
      ar: "ليان مكان صغير للعناية، لا سلسلة ولا وعد بنتيجة جاهزة. نسمع الطلب، نرتّب الوقت، ثم نعمل بهدوء حتى آخر لمسة.",
      en: "Layan is a small house of care, not a chain and not a promise of a finished result. We listen, we set the time, then we work quietly through the last detail.",
    },
    points: [
      {
        title: { ar: "استماع أولاً", en: "Listening first" },
        text: {
          ar: "دقائق في البداية لفهم ما تريدينه قبل أن تبدأ الخدمة.",
          en: "A few minutes at the start, so the service follows what you actually want.",
        },
      },
      {
        title: { ar: "وقت محسوب", en: "Time with room in it" },
        text: {
          ar: "لكل خدمة مدة ظاهرة، حتى لا تتزاحم المواعيد فوق بعضها.",
          en: "Every service shows its duration, so appointments are not stacked on top of each other.",
        },
      },
      {
        title: { ar: "طلب لا تأكيد", en: "A request, not a confirmation" },
        text: {
          ar: "ما يُرسل من الموقع طلب زيارة. الموعد يثبت حين يرد الصالون.",
          en: "What the site sends is a request. The visit is set when the salon replies.",
        },
      },
    ],
  },
  gallery: {
    kicker: { ar: "المعرض", en: "Gallery" },
    title: { ar: "ضوء، أدوات، وأيدٍ تعمل", en: "Light, tools, and hands at work" },
    lead: {
      ar: "لقطات للعناية والمكان. ليست صوراً لضيفات، ولا نتائج قبل وبعد.",
      en: "Frames of the work and the room. Not guest portraits, and not before-and-after claims.",
    },
    open: { ar: "تكبير الصورة", en: "Enlarge image" },
    close: { ar: "إغلاق المعرض", en: "Close gallery" },
    prev: { ar: "الصورة السابقة", en: "Previous image" },
    next: { ar: "الصورة التالية", en: "Next image" },
  },
  experience: {
    kicker: { ar: "الزيارة", en: "The visit" },
    title: { ar: "ثلاث خطوات، من غير تعقيد", en: "Three steps, and no fuss" },
    steps: [
      {
        title: { ar: "تختارين الخدمة", en: "Choose the service" },
        text: {
          ar: "من القائمة مباشرة، أو تتركين الاختيار مفتوحاً ونرتّبه معك.",
          en: "From the list, or leave it open and we arrange it with you.",
        },
      },
      {
        title: { ar: "تحدّدين يوماً ووقتاً", en: "Pick a day and a time" },
        text: {
          ar: "الأوقات في هذا النموذج توضيحية، وتصير جدول الصالون عند الربط.",
          en: "Times in this demo are illustrative. They become the salon’s own schedule once connected.",
        },
      },
      {
        title: { ar: "يصل طلب، لا موعد مؤكد", en: "A request arrives, not a confirmed booking" },
        text: {
          ar: "ترسلين بياناتك، ويظهر رقم طلب تجريبي. التأكيد الفعلي يتم خارج هذا النموذج.",
          en: "You send your details and receive a demo request number. A real confirmation happens outside this demo.",
        },
      },
    ],
  },
  visit: {
    kicker: { ar: "التواصل", en: "Contact" },
    title: { ar: "العنوان والوقت، حين تكتمل البيانات", en: "Address and hours, once they are real" },
    lead: {
      ar: "لا نعرض عنواناً أو رقماً غير موجود. الحقول التالية تنتظر بيانات الصالون.",
      en: "We do not show an address or a number that does not exist. These fields wait for the salon’s own details.",
    },
    address: { ar: "العنوان", en: "Address" },
    phone: { ar: "الهاتف", en: "Phone" },
    hours: { ar: "ساعات العمل", en: "Hours" },
    whatsapp: { ar: "واتساب", en: "WhatsApp" },
    whatsappMissing: {
      ar: "واتساب يظهر بعد إضافة الرقم",
      en: "WhatsApp appears after the number is added",
    },
    instagram: { ar: "إنستغرام", en: "Instagram" },
    mapTitle: { ar: "خريطة الصالون", en: "Salon map" },
    mapEmpty: {
      ar: "الخريطة تُربط بعنوان الصالون عند التخصيص.",
      en: "The map is connected to the salon’s address when you customize the site.",
    },
    book: { ar: "ابدئي طلب الحجز", en: "Start a booking request" },
  },
  book: {
    kicker: { ar: "طلب موعد", en: "Booking request" },
    title: { ar: "أخبرينا متى يناسبك الحضور", en: "Tell us when you would like to come" },
    lead: {
      ar: "هذا النموذج تجريبي. الطلب يُحفظ على جهازك فقط، ولا يُعد موعداً مؤكداً.",
      en: "This form is a demo. The request stays on your device and is not a confirmed appointment.",
    },
    service: { ar: "الخدمة", en: "Service" },
    name: { ar: "الاسم", en: "Name" },
    phone: { ar: "الجوال", en: "Mobile" },
    date: { ar: "اليوم", en: "Day" },
    time: { ar: "الوقت", en: "Time" },
    submit: { ar: "إرسال الطلب", en: "Send request" },
    sending: { ar: "جارٍ الإرسال", en: "Sending" },
    namePh: { ar: "اسمك الكريم", en: "Your name" },
    phonePh: { ar: "05xxxxxxxx", en: "05xxxxxxxx" },
    successTitle: { ar: "وصل طلبك التجريبي", en: "Your demo request is in" },
    successBody: {
      ar: "احتفظنا بالتفاصيل على هذا الجهاز. لم يُثبَّت موعد حقيقي، ولم تُرسل رسالة إلى صالون.",
      en: "The details are stored on this device. No real appointment was confirmed, and nothing was sent to a salon.",
    },
    reference: { ar: "رقم الطلب التجريبي", en: "Demo request number" },
    another: { ar: "طلب جديد", en: "New request" },
    whatsappCta: { ar: "تابعي عبر واتساب", en: "Continue on WhatsApp" },
    errors: {
      service: { ar: "اختاري خدمة.", en: "Choose a service." },
      name: { ar: "اكتبي الاسم كما تحبين أن نناديك.", en: "Add the name you would like us to use." },
      phone: { ar: "أدخلي رقم جوال سعودي صحيح، مثل 05xxxxxxxx.", en: "Enter a valid Saudi mobile, such as 05xxxxxxxx." },
      date: { ar: "اختاري يوماً قادماً خلال الشهرين التاليين.", en: "Choose a coming day within the next two months." },
      time: { ar: "اختاري وقتاً من القائمة.", en: "Choose a time from the list." },
    },
  },
  footer: {
    line: {
      ar: "نموذج موقع لصالون تجميل في الرياض. الاسم والصور وبيانات التواصل قابلة للتخصيص.",
      en: "A website demo for a Riyadh beauty salon. The name, photographs, and contact details can be customized.",
    },
    rights: { ar: "جميع الحقوق محفوظة للنموذج التصميمي.", en: "Design demo. All rights reserved." },
    photos: { ar: "الصور الفوتوغرافية من Unsplash.", en: "Photographs from Unsplash." },
  },
} as const;

export function pick(locale: Locale, value: { readonly ar: string; readonly en: string }) {
  return value[locale];
}
