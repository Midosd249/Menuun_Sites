import { createFileRoute } from "@tanstack/react-router";
import { Experience } from "@/components/salon/experience";
import { Gallery } from "@/components/salon/gallery";
import { Hero } from "@/components/salon/hero";
import { Services } from "@/components/salon/services";
import { Story } from "@/components/salon/story";
import { Visit } from "@/components/salon/visit";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "أتيليه ليان — صالون تجميل في الرياض" },
      {
        name: "description",
        content:
          "تجربة موقع لصالون نسائي في الرياض: تصفيف، تلوين، أظافر، عناية بالبشرة، وإطلالة عروس، مع طلب حجز تجريبي.",
      },
    ],
    links: [{ rel: "preload", as: "image", href: "/images/hero.jpg" }],
  }),
  component: Home,
});

function Home() {
  return (
    <main id="content">
      <Hero />
      <Services />
      <Story />
      <Gallery />
      <Experience />
      <Visit />
    </main>
  );
}
