import { createFileRoute } from "@tanstack/react-router";
import { BookingForm } from "@/components/salon/booking-form";

type BookSearch = {
  service?: string;
};

export const Route = createFileRoute("/book")({
  validateSearch: (search: Record<string, unknown>): BookSearch => ({
    service: typeof search.service === "string" ? search.service : undefined,
  }),
  head: () => ({
    meta: [
      { title: "طلب موعد — أتيليه ليان" },
      {
        name: "description",
        content: "اطلبي موعداً تجريبياً في أتيليه ليان: اختاري الخدمة، اليوم، والوقت. الطلب لا يُعد تأكيداً نهائياً.",
      },
    ],
  }),
  component: BookPage,
});

function BookPage() {
  const { service } = Route.useSearch();
  return (
    <main id="content" className="border-t border-line">
      <BookingForm key={service ?? "open"} initialServiceId={service} />
    </main>
  );
}
